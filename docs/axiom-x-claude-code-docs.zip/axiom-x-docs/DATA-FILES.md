# Data Files for Axiom X

> **For Claude Code:** Create these files in the `data/` directory during Phase 1.

---

## data/navigation.ts

```typescript
export interface NavLink {
  label: string;
  href: string;
}

export const navLinks: NavLink[] = [
  { label: "Home", href: "#hero" },
  { label: "Services", href: "#services" },
  { label: "Why AxiomX", href: "#why-axiom" },
  { label: "About", href: "#our-story" },
  { label: "Contact", href: "#contact" },
];

export const footerLinks = {
  quickLinks: [
    { label: "Privacy Policy", href: "/privacy" },
    { label: "Terms Of Use", href: "/terms" },
    { label: "FAQ", href: "/faq" },
    { label: "Contact", href: "#contact" },
  ],
  account: [
    { label: "My Account", href: "/account" },
    { label: "Login / Register", href: "/login" },
  ],
};
```

---

## data/site-config.ts

```typescript
export const siteConfig = {
  name: "Axiom X",
  tagline: "Your operational growth engine",
  description:
    "From first mile to final revenue touchpoint, we power the unseen. Axiom X helps you find untapped potential and turn it into execution, insight, and growth.",
  contact: {
    email: "hello@Axiomx.com",
    phone: "+971 4 123 4567",
    regions: ["UAE", "KSA", "Oman", "Kuwait"],
  },
  social: {
    linkedin: "https://linkedin.com/company/axiomx",
    twitter: "https://twitter.com/axiomx",
    // Add more as needed
  },
};
```

---

## data/hero-slides.ts

```typescript
export interface HeroSlide {
  id: number;
  headline: string;
  subtext: string;
  ctaPrimary: string;
  ctaSecondary: string;
  backgroundImage?: string;
}

export const heroSlides: HeroSlide[] = [
  {
    id: 1,
    headline: "From first mile to final revenue touchpoint, we power the unseen.",
    subtext:
      "Your operations have untapped potential. Axiom X helps you find it and turn it into execution, insight, and growth.",
    ctaPrimary: "Speak to an Expert",
    ctaSecondary: "Create an Account",
  },
  {
    id: 2,
    headline: "Are you Searching for X?",
    subtext:
      "At Axiom X, we don't sell services. We offer a system. One that thinks, scales, and adapts with your business.",
    ctaPrimary: "Speak to an Expert",
    ctaSecondary: "Create an Account",
  },
  {
    id: 3,
    headline: "29+ Facilities. 99.9% Accuracy. One Platform.",
    subtext:
      "Our AI-enhanced ecosystem was built for the operational complexity that most businesses are only now realizing they need to solve.",
    ctaPrimary: "Speak to an Expert",
    ctaSecondary: "Create an Account",
  },
];
```

---

## data/stats.ts

```typescript
export interface Stat {
  id: string;
  value: number;
  suffix: string;
  label: string;
  decimals?: number;
}

export const stats: Stat[] = [
  {
    id: "orders",
    value: 2000000,
    suffix: "+",
    label: "Yearly Orders Delivered",
  },
  {
    id: "upsells",
    value: 600000,
    suffix: "+",
    label: "Activated Monthly Upsells",
  },
  {
    id: "sla",
    value: 98,
    suffix: "%",
    label: "SLA Delivery Rate",
  },
  {
    id: "support",
    value: 140000,
    suffix: "",
    label: "Tech Support Cases Resolved",
  },
];

export const additionalStats: Stat[] = [
  {
    id: "accuracy",
    value: 99.9,
    suffix: "%",
    label: "Inventory Accuracy",
    decimals: 1,
  },
  {
    id: "facilities",
    value: 29,
    suffix: "+",
    label: "Facilities",
  },
];
```

---

## data/services.ts

```typescript
export interface Service {
  id: string;
  title: string;
  description: string;
  features: string[];
  image: string;
  icon?: string; // Lucide icon name
}

export const services: Service[] = [
  {
    id: "warehousing",
    title: "Warehousing & Inventory",
    description:
      "Storage built for action, not stagnation. From inventory intelligence to optimized flow, our fulfillment-first warehouses are ready for your growth — and your complexity.",
    features: [
      "29 warehouses, 122K+ sqft capacity",
      "99.9% inventory accuracy",
      "Real-time dashboards via WMS integrations",
      "Modular zoning, temperature-controlled environments",
    ],
    image: "/images/services/warehousing.jpg",
    icon: "Warehouse",
  },
  {
    id: "call-center",
    title: "Call Center Support",
    description:
      "Customer engagement that drives loyalty and retention. Our trained teams handle inquiries, complaints, and support with precision and care.",
    features: [
      "24/7 multilingual support",
      "AI-assisted call routing",
      "Quality monitoring and analytics",
      "Seamless CRM integration",
    ],
    image: "/images/services/call-center.jpg",
    icon: "Headphones",
  },
  {
    id: "back-office",
    title: "Back Office Services",
    description:
      "Streamline your administrative operations. We handle the paperwork so you can focus on growth.",
    features: [
      "Order processing and management",
      "Data entry and verification",
      "Invoice and payment processing",
      "Reporting and analytics",
    ],
    image: "/images/services/back-office.jpg",
    icon: "FileText",
  },
  {
    id: "vas",
    title: "Value-Added Services (VAS)",
    description:
      "Go beyond basic fulfillment. Our VAS capabilities add value at every touchpoint of your supply chain.",
    features: [
      "Kitting and bundling",
      "Custom packaging and labeling",
      "Quality inspection",
      "Returns processing",
    ],
    image: "/images/services/vas.jpg",
    icon: "Package",
  },
  {
    id: "upselling",
    title: "Upselling Revenue Programs",
    description:
      "Turn every customer interaction into a revenue opportunity. Our proven upselling programs drive incremental growth.",
    features: [
      "600K+ monthly activated upsells",
      "AI-powered recommendation engine",
      "Performance-based compensation",
      "Real-time conversion tracking",
    ],
    image: "/images/services/upselling.jpg",
    icon: "TrendingUp",
  },
];
```

---

## data/brand-values.ts

```typescript
export interface BrandValue {
  id: string;
  label: string;
  icon: string; // Lucide icon name
  description?: string;
}

export const brandValues: BrandValue[] = [
  {
    id: "precision",
    label: "Precision",
    icon: "Target",
    description: "Accuracy in every operation",
  },
  {
    id: "agility",
    label: "Agility",
    icon: "Zap",
    description: "Adapting to change swiftly",
  },
  {
    id: "reliability",
    label: "Reliability",
    icon: "Shield",
    description: "Consistent, dependable service",
  },
  {
    id: "support",
    label: "Support",
    icon: "HeartHandshake",
    description: "Partnership at every step",
  },
  {
    id: "innovation",
    label: "Innovation",
    icon: "Lightbulb",
    description: "AI-driven solutions",
  },
];
```

---

## data/content.ts

```typescript
export const content = {
  whyAxiom: {
    headline: "Why Axiom X?",
    subheadline:
      "You don't just need to outsource. You need to outsmart, outscale, and out-deliver.",
    description:
      "Our AI-enhanced ecosystem was built for the operational complexity that most businesses are only now realizing they need to solve. Axiom X isn't just a service provider — we're your operational growth engine.",
    ctaPrimary: "Speak to an Expert",
    ctaSecondary: "Create an Account",
  },

  ourStory: {
    headline: "OUR STORY: FROM 1997 TO THE AI ERA",
    content:
      "We started in 1997 as Axiom X Telecom — building the Middle East's largest mobility distribution engine. We helped global brands scale through precision logistics, resilient warehousing, and high-volume fulfillment. Today, we combine that legacy with AI-driven innovation to power the next generation of business operations.",
    cta: "Read full story",
  },

  vision: {
    headline: "Vision",
    content:
      "To be the unseen force powering the next era of business operations.",
  },

  mission: {
    headline: "Mission",
    content:
      "To simplify, enable, and scale modern operations through intelligent, AI-driven services.",
  },

  careers: {
    headline: "Build the future of operations.",
    subheadline:
      "We're looking for operators, strategists, and technologists ready to redesign what B2B execution looks like in the Middle East.",
    ctaPrimary: "Join the X Team",
    ctaSecondary: "READ MORE CAREERS",
  },

  contact: {
    headline: "Let's talk scale.",
    subheadline:
      "Whether you're looking to optimize delivery, centralize operations, or unlock new revenue — Axiom X is your growth partner.",
  },

  tracking: {
    headline: "Real-time Tracking for your Shipments",
    placeholder: "Tracking Number",
    helperText: "* enter the tracking number provided by the company.",
    buttonText: "Track",
  },

  newsletter: {
    headline: "Subscribe",
    description: "Get 10% off your first order",
    placeholder: "Enter your email",
    buttonText: "Subscribe",
  },
};
```

---

## lib/validations.ts

```typescript
import { z } from "zod";

export const contactSchema = z.object({
  fullName: z
    .string()
    .min(2, "Name must be at least 2 characters")
    .max(100, "Name is too long"),
  email: z.string().email("Please enter a valid email address"),
  message: z
    .string()
    .min(10, "Message must be at least 10 characters")
    .max(1000, "Message is too long"),
});

export const newsletterSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
});

export const trackingSchema = z.object({
  trackingNumber: z
    .string()
    .min(5, "Please enter a valid tracking number")
    .max(50, "Tracking number is too long"),
});

// Type exports
export type ContactFormData = z.infer<typeof contactSchema>;
export type NewsletterFormData = z.infer<typeof newsletterSchema>;
export type TrackingFormData = z.infer<typeof trackingSchema>;
```

---

## lib/constants.ts

```typescript
// Re-export everything for convenience
export { siteConfig } from "@/data/site-config";
export { navLinks, footerLinks } from "@/data/navigation";
export { heroSlides } from "@/data/hero-slides";
export { stats, additionalStats } from "@/data/stats";
export { services } from "@/data/services";
export { brandValues } from "@/data/brand-values";
export { content } from "@/data/content";
```

---

*Copy these files into your project during setup.*
